exports.removeSpaces = (str) => {
    let text1 = str;
    let text2 = text1.replace(/ /g, "");
    return text2;
  };
  